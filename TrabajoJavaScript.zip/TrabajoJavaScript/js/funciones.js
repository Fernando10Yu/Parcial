// JavaScript Document

var cronometro;
var sliderr;

function detenerse()
{
	clearInterval(cronometro);
}

function carga()
{
	contador_mls = 0;
	contador_s = 0;
	contador_m = 0;
	
	mls = document.getElementById("ml_segundos");
	s = document.getElementById("segundos");
	m = document.getElementById("minutos");
	
	cronometro = setInterval(
	function(){
		if (contador_mls==60) {
			contador_mls = 0;
			contador_s++;
			s.innerHTML = contador_s;
			
			if (contador_s==60) {
				contador_s = 0;
				contador_m++;
				m.innerHTML = contador_m;
			}
		}
		mls.innerHTML = contador_mls;
		contador_mls++;
		
	}
	,16);
	 
}

<!--  ///  Finaliza función para cronómetro  ///  -->

<!--  ///  Comienza Script para cambio de color en letras  ///  -->

function color()
{
	if (sliderr==1) {
	sliderr=2;
document.getElementById("cambio1").innerHTML= document.fgColor.color('yellow');
	}
}

