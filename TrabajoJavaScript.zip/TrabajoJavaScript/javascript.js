// JavaScript Document

var cronometro;

function detenerse()
{
	clearInterval(cronometro);
}

function cargar()
{
	contador_mls = 0;
	contador_s = 0;
	contador_m = 0;
	
	contador_mls = document.getElementById("ml_segundos");
	contador_s = document.getElementById("segundos");
	contador_m = document.getElementById("minutos");
	
	cronometro = setInterval(
	function(){
		if (contador_mls==60) {
			contador_mls = 0;
			contador_s++;
			s.innerHTML = contador_s;
			
			if (contador_s==60) {
				contador_s = 0;
				contador_m++;
				m.innerHTML = contador_m;
			}
		}
		mls.innerHTML = contador_mls;
		contador_mls++;
		
	}
	,1);
	 
}